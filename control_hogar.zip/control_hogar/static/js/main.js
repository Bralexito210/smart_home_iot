function enviarComando(comando) {
  fetch(`/comando?accion=${comando}`)
    .then(res => res.text())
    .then(msg => console.log(msg));
}

function reconocerVoz() {
  const reco = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
  reco.lang = 'es-PE';
  reco.start();

  reco.onresult = (event) => {
    const texto = event.results[0][0].transcript.toLowerCase();
    document.getElementById("comandoReconocido").innerText = "Comando: " + texto;

    for (let i = 1; i <= 6; i++) {
      if (texto.includes(`encender foco ${i}`)) return enviarComando(`foco${i}_on`);
      if (texto.includes(`apagar foco ${i}`)) return enviarComando(`foco${i}_off`);
    }

    if (texto.includes("abrir puerta")) enviarComando("abrir_puerta");
    else if (texto.includes("cerrar puerta")) enviarComando("cerrar_puerta");
    else alert("Comando no reconocido");
  };
}
