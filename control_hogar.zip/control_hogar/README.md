# Proyecto: Control de Foco y Puerta con Botones y Voz

Este proyecto permite controlar un foco y una puerta a través de una interfaz web usando botones o comandos de voz. El backend está hecho con Flask y la comunicación con el Arduino se hace por Serial.

## Cómo ejecutar

1. Instala las dependencias:
   pip install -r requirements.txt

2. Conecta el Arduino por USB y verifica el puerto (cambia COM3 si es necesario en control.py).

3. Ejecuta la app:
   python app.py

4. Abre en el navegador: http://127.0.0.1:5000
