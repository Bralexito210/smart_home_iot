from flask import Blueprint, request, render_template
from .control import ejecutar_comando

main = Blueprint('main', __name__)

@main.route('/')
def index():
    return render_template('index.html')

@main.route('/comando')
def comando():
    accion = request.args.get('accion')
    ejecutar_comando(accion)
    return f"Comando '{accion}' recibido", 200