import serial

arduino = serial.Serial('COM3', 9600, timeout=1)

def ejecutar_comando(accion):
    comandos_validos = {
        # Focos
        "foco1_on": "F1ON", "foco1_off": "F1OFF",
        "foco2_on": "F2ON", "foco2_off": "F2OFF",
        "foco3_on": "F3ON", "foco3_off": "F3OFF",
        "foco4_on": "F4ON", "foco4_off": "F4OFF",
        "foco5_on": "F5ON", "foco5_off": "F5OFF",
        "foco6_on": "F6ON", "foco6_off": "F6OFF",

        # Puerta
        "abrir_puerta": "P1",
        "cerrar_puerta": "P0"
    }

    if accion in comandos_validos:
        arduino.write((comandos_validos[accion] + '\n').encode())
